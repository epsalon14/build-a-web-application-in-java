# java-maven-web-app
A simple Java and Maven Web Application
